# Dados Compartilhados SandBox DREX Banrisul-SERPRO

O arquivo genesis.json é baseado no genesis disponibilizado pelo Banco Central (https://github.com/bacen/pilotord-kit-onboarding) e define o primeiro bloco da rede blockchain, contendo:

- Endereços dos 6 validadores do primeiro bloco no atributo extraData.
- Versão da EVM "London" para o primeiro bloco.
- Definição de uma rede "free gas".
- Tempo de intervalo entre produção de blocos de 20 segundos.

Todos os nós participantes da rede blockchain devem utilizar o mesmo arquivo genesis.json

## Geração do atributo extraData

O atributo "extraData" contém, no arquivo genesis.json, a definição dos validadores do primeiro bloco e da rede blockchain.
Para obter o endereço de um node a partir de sua chave privada (https://besu.hyperledger.org/public-networks/concepts/node-keys#node-address):

```
docker run --mount type=bind,src=<CAMINHO/PASTA/DATA>.,dst=/var/lib/besu hyperledger/besu:23.10.1 public-key export-address --node-private-key-file=<ARQUIVO-CHAVE> --to=address
```

Para gerar o extraData a partir de endereços conhecidos dos nós validadores, criamos uma lista com estes endereços no arquivo validadoresAddress.json e utilizamos o comando (https://besu.hyperledger.org/private-networks/how-to/configure/consensus/ibft#extra-data):

```
docker run --mount type=bind,src=.,dst=/var/lib/besu hyperledger/besu:23.10.1 rlp encode --from=/var/lib/besu/validadoresAddress.json --to=/var/lib/besu/extraData --type=QBFT_EXTRA_DATA
```

## Permissionamento de nodes na rede

O permissionamento de nodes pode ser feito onchain via contrato ou de forma local na configuração de cada node.

Para realizar o permissionamento de forma local, utiliza-se um arquivo "permissions-config.toml" que define um atributo "nodes-allowlist" contendo uma lista com os enode URL dos nós.
Na configuração do nó (arquivo config.toml, linha de comando ou variáveis de ambiente), utilizar as opções "--permissions-nodes-config-file-enabled=true" e "--permissions-nodes-config-file=caminho/para/permissions-config.toml"

Especificar no arquivo permissions-config.toml os endereços IP e portas dos nodes. A ordem dos nodes na lista é validador-serpro-{1-3}, fullnode-serpro-1, validador-banrisul-{1-3}, fullnode-banrisul-1

## Static Nodes

O arquivo static-nodes.json especifica os enode URL dos peers da rede.
Na configuração do nó (arquivo config.toml, linha de comando ou variáveis de ambiente), utilizar as opções "--discovery-enabled=false" e "--static-nodes-file=/caminho/para/static-nodes.json"

Especificar no arquivo static-nodes.json os endereços IP e portas dos nodes. A ordem dos nodes na lista é validador-serpro-{1-3}, fullnode-serpro-1, validador-banrisul-{1-3}, fullnode-banrisul-1
